# Panduan Trading Komoditas

## Gold (XAU/USD)

### Karakteristik Gold
- **Safe Haven Asset** - Menguat saat ketidakpastian/krisis
- **Inverse USD** - Umumnya bergerak berlawanan dengan Dollar
- **Inflation Hedge** - Dianggap pelindung nilai terhadap inflasi
- **Volume Tinggi** - Salah satu instrument paling liquid

### Faktor Penggerak Gold
1. **US Dollar** - USD naik = Gold turun (inverse correlation)
2. **Real Interest Rates** - Yield tinggi = Gold turun (opportunity cost)
3. **Inflation Expectations** - Inflasi tinggi = Gold naik
4. **Geopolitical Risk** - Perang, krisis = Gold naik
5. **Central Bank Buying** - Bank sentral beli gold = bullish
6. **Risk Sentiment** - Risk-off = Gold naik

### Waktu Trading Gold
- **Jam Aktif**: London & New York overlap (19:00-23:00 WIB)
- **Asian Session**: Lebih tenang, range lebih kecil
- **Perhatikan**: US data release, Fed speeches

### Trading Gold Tips
1. Perhatikan DXY (Dollar Index) untuk konfirmasi
2. Watch US Treasury yields (10-year yield important)
3. Gold bisa sangat volatil saat US news
4. Support/Resistance di level psikologis (1900, 2000, dll)
5. Trend gold bisa sangat panjang (monthly/yearly)

### Level Psikologis Gold
- Level round numbers: 1800, 1850, 1900, 1950, 2000, dst
- Sering jadi area S/R kuat

## Silver (XAG/USD)

### Karakteristik Silver
- **Industrial + Precious Metal** - Hybrid demand
- **Lebih Volatil dari Gold** - Movement lebih besar percentage-wise
- **Gold/Silver Ratio** - Biasanya 60-80 (gold/silver price)
- **Lebih Murah** - Accessible untuk trader kecil

### Faktor Penggerak Silver
1. **Gold Movement** - Highly correlated dengan gold
2. **Industrial Demand** - Electronics, solar panels
3. **USD Strength** - Inverse correlation
4. **Risk Sentiment** - Lebih sensitif dari gold

### Tips Trading Silver
1. Silver lebih "liar" dari gold
2. Butuh SL lebih lebar (percentage-wise)
3. Perhatikan gold sebagai leading indicator
4. Industrial demand bisa decouple dari gold

## Oil (Crude Oil)

### Jenis Oil yang Diperdagangkan
1. **WTI (West Texas Intermediate)** - US benchmark, symbol: CL atau USOIL
2. **Brent Crude** - International benchmark, symbol: UKOIL
3. **Spread WTI-Brent** - Biasanya Brent > WTI

### Karakteristik Oil
- **Sangat Volatil** - Bisa bergerak 3-5% dalam sehari
- **Geopolitical Sensitive** - Sangat reaktif terhadap news
- **Supply/Demand Driven** - Fundamental sangat penting
- **Seasonal Patterns** - Driving season, heating season

### Faktor Penggerak Oil
1. **OPEC Decisions** - Produksi naik/turun = harga turun/naik
2. **US Inventory Data** - Weekly report (Rabu malam WIB)
3. **Geopolitical Events** - Middle East tensions, sanctions
4. **Global Demand** - China demand sangat penting
5. **USD Strength** - Oil priced in USD
6. **Rig Count** - US production indicator

### Data Penting untuk Oil
1. **API Weekly Crude Stocks** - Selasa malam WIB (preview)
2. **EIA Crude Oil Inventories** - Rabu malam 21:30 WIB (official)
3. **Baker Hughes Rig Count** - Jumat malam WIB

### Tips Trading Oil
1. SELALU cek kalender untuk inventory data
2. Volatilitas extreme saat OPEC meetings
3. Perhatikan geopolitik Middle East
4. Korelasi dengan CAD (Canada oil exporter)
5. Trend oil bisa sangat kuat dan panjang

### Level Psikologis Oil
- Level $5 increments: 70, 75, 80, 85, 90, dst
- Level round numbers sering jadi S/R

## Komoditas Lainnya

### Natural Gas
- Sangat volatil, seasonal (winter heating demand)
- Bukan untuk pemula

### Copper (Tembaga)
- Industrial metal, barometer ekonomi global
- Korelasi dengan China manufacturing

### Platinum & Palladium
- Industrial use (catalytic converters)
- Lebih volatil dari gold

## Perbandingan Karakteristik

| Komoditas | Volatilitas | Spread | Best For |
|-----------|-------------|--------|----------|
| Gold | Medium-High | Kecil | Swing, Position |
| Silver | High | Medium | Swing |
| WTI Oil | Very High | Medium | Day, Swing |
| Brent Oil | Very High | Medium | Day, Swing |

## Risk Management Komoditas

### Position Sizing
1. Komoditas lebih volatil dari forex
2. Kurangi lot size 30-50% dibanding forex
3. ATR (Average True Range) untuk ukur volatilitas

### Stop Loss
1. Lebih lebar dari forex (pip-wise)
2. Perhatikan ATR harian
3. Jangan SL terlalu dekat di market volatil

### Waktu High Risk (Hindari/Hati-hati)
1. OPEC meetings (Oil)
2. US Inventory data (Oil)
3. FOMC/Fed (Gold)
4. Major geopolitical events
5. US CPI/NFP release

## Korelasi Komoditas

### Gold Correlations
- Negative: USD, Real Yields
- Positive: Silver, Inflation expectations

### Oil Correlations
- Positive: CAD, NOK (commodity currencies)
- Negative: Airline stocks, Transportation sector

### Tips Menggunakan Korelasi
1. Jangan long gold dan long USD bersamaan
2. Oil naik = pertimbangkan long CAD
3. Gold bisa jadi hedge untuk posisi risk-on
