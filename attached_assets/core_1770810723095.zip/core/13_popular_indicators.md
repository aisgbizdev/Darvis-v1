# Indikator Teknikal Populer

## Moving Average (MA)

### Jenis Moving Average
1. **SMA (Simple MA)** - Rata-rata harga sederhana. Lebih smooth tapi lagging
2. **EMA (Exponential MA)** - Lebih responsif terhadap harga terbaru
3. **WMA (Weighted MA)** - Memberi bobot lebih pada harga terbaru

### Setting Populer
- **MA 20** - Short-term trend (1 bulan trading)
- **MA 50** - Medium-term trend
- **MA 100** - Long-term trend
- **MA 200** - Major trend, sering jadi dynamic support/resistance

### Cara Menggunakan MA
1. **Trend Filter** - Harga di atas MA = uptrend, di bawah = downtrend
2. **Dynamic S/R** - MA sering jadi area bounce
3. **Crossover** - MA cepat cross MA lambat = sinyal entry
   - Golden Cross (MA cepat cross up) = Bullish
   - Death Cross (MA cepat cross down) = Bearish

## RSI (Relative Strength Index)

### Setting Default: Period 14

### Interpretasi RSI
- **RSI > 70** - Overbought (jenuh beli), potensi koreksi turun
- **RSI < 30** - Oversold (jenuh jual), potensi koreksi naik
- **RSI 50** - Level netral

### Cara Trading dengan RSI
1. **Divergence** - Harga naik tapi RSI turun = bearish divergence (potensi reversal)
2. **Overbought/Oversold** - Jangan langsung entry, tunggu konfirmasi
3. **Trend Confirmation** - RSI di atas 50 = bullish bias, di bawah 50 = bearish bias

### Tips RSI
- Di trend kuat, RSI bisa stay overbought/oversold lama
- Gunakan dengan konfirmasi lain (price action, S/R)
- Divergence adalah sinyal warning, bukan entry langsung

## MACD (Moving Average Convergence Divergence)

### Komponen MACD
1. **MACD Line** - EMA 12 minus EMA 26
2. **Signal Line** - EMA 9 dari MACD line
3. **Histogram** - Selisih MACD line dan Signal line

### Sinyal MACD
1. **Crossover** 
   - MACD cross up Signal = Bullish
   - MACD cross down Signal = Bearish
2. **Zero Line Cross**
   - MACD cross up zero = Bullish momentum
   - MACD cross down zero = Bearish momentum
3. **Divergence**
   - Harga higher high, MACD lower high = Bearish divergence
   - Harga lower low, MACD higher low = Bullish divergence

### Tips MACD
- Lebih efektif di trending market
- Lagging indicator, jangan gunakan untuk scalping
- Kombinasikan dengan price action untuk konfirmasi

## Bollinger Bands

### Komponen (Setting Default: 20, 2)
1. **Middle Band** - SMA 20
2. **Upper Band** - SMA 20 + (2 x Standard Deviation)
3. **Lower Band** - SMA 20 - (2 x Standard Deviation)

### Interpretasi
1. **Band Width** 
   - Menyempit (squeeze) = Volatilitas rendah, potensi breakout
   - Melebar = Volatilitas tinggi
2. **Price Position**
   - Menyentuh upper band = Overbought area
   - Menyentuh lower band = Oversold area

### Strategi Bollinger Bands
1. **Mean Reversion** - Harga cenderung kembali ke middle band
2. **Breakout** - Setelah squeeze, trade arah breakout
3. **Trend Following** - Di strong trend, harga bisa "riding the band"

### Tips BB
- Jangan otomatis sell di upper / buy di lower band
- Tunggu konfirmasi (candlestick pattern, RSI divergence)
- Di strong trend, harga bisa stay di luar band

## Stochastic Oscillator

### Setting Default: 14, 3, 3

### Komponen
1. **%K Line** - Fast stochastic
2. **%D Line** - SMA 3 dari %K (slow/signal line)

### Interpretasi
- **> 80** - Overbought zone
- **< 20** - Oversold zone

### Sinyal Trading
1. **Crossover di extreme zone**
   - %K cross up %D di oversold = Buy signal
   - %K cross down %D di overbought = Sell signal
2. **Divergence** - Sama seperti RSI

### Tips Stochastic
- Lebih sensitif dari RSI
- Cocok untuk ranging market
- Di trending market, bisa memberikan false signal

## Kombinasi Indikator yang Efektif

### Setup 1: Trend + Momentum
- MA 50 & MA 200 (trend filter)
- RSI 14 (momentum confirmation)
- Entry: Searah trend, RSI tidak extreme

### Setup 2: Volatility + Momentum
- Bollinger Bands
- Stochastic atau RSI
- Entry: BB squeeze breakout + momentum confirmation

### Setup 3: Multi-MA System
- EMA 8, EMA 21, EMA 55
- Entry: Semua MA aligned (stacking)
- Price pullback ke EMA terdekat

### Aturan Penting
1. Jangan overload chart dengan terlalu banyak indikator
2. Maksimal 2-3 indikator yang saling melengkapi
3. Indikator adalah konfirmasi, bukan holy grail
4. Price action tetap yang utama
