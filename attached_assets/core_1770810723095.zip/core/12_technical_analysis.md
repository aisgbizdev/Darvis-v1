# Analisis Teknikal Dasar

## Candlestick Patterns

### Bullish Patterns (Sinyal Naik)
1. **Hammer** - Body kecil di atas, shadow panjang di bawah. Muncul di downtrend = potensi reversal naik
2. **Bullish Engulfing** - Candle hijau besar "menelan" candle merah sebelumnya
3. **Morning Star** - 3 candle: merah besar → doji/kecil → hijau besar. Sinyal reversal kuat
4. **Three White Soldiers** - 3 candle hijau berturut-turut dengan higher close

### Bearish Patterns (Sinyal Turun)
1. **Shooting Star** - Body kecil di bawah, shadow panjang di atas. Muncul di uptrend = potensi reversal turun
2. **Bearish Engulfing** - Candle merah besar "menelan" candle hijau sebelumnya
3. **Evening Star** - 3 candle: hijau besar → doji/kecil → merah besar. Sinyal reversal kuat
4. **Three Black Crows** - 3 candle merah berturut-turut dengan lower close

### Continuation Patterns
1. **Doji** - Open = Close, menunjukkan keraguan pasar
2. **Spinning Top** - Body kecil dengan shadow atas dan bawah seimbang

## Support & Resistance

### Support (Area Demand)
- Level harga dimana buyer cenderung masuk
- Harga sudah beberapa kali "mental" dari level ini
- Semakin sering ditest, semakin kuat (tapi bisa juga semakin lemah jika terlalu sering)

### Resistance (Area Supply)
- Level harga dimana seller cenderung masuk
- Harga sudah beberapa kali "ditolak" dari level ini
- Jika break resistance, bisa jadi support baru (role reversal)

### Cara Menggambar S/R
1. Cari swing high dan swing low yang jelas
2. Gunakan body candle, bukan shadow
3. Buat sebagai zona (area), bukan garis tipis
4. Konfirmasi dengan volume tinggi

## Trendlines

### Uptrend Line
- Hubungkan minimal 2 higher lows
- Harga bergerak di atas trendline
- Break trendline = potensi trend change

### Downtrend Line
- Hubungkan minimal 2 lower highs
- Harga bergerak di bawah trendline
- Break trendline = potensi trend change

### Tips Menggambar Trendline
1. Minimal 2 titik sentuh (3 lebih valid)
2. Semakin banyak sentuhan, semakin valid
3. Sudut 45 derajat paling sustainable
4. Trendline terlalu curam = tidak sustainable

## Chart Patterns

### Reversal Patterns
1. **Head & Shoulders** - Pola kepala dan dua bahu. Neckline break = entry sell
2. **Inverse Head & Shoulders** - Kebalikan H&S. Neckline break = entry buy
3. **Double Top** - Harga gagal break resistance 2x. Break support = sell
4. **Double Bottom** - Harga gagal break support 2x. Break resistance = buy
5. **Triple Top/Bottom** - Sama seperti double tapi 3x test

### Continuation Patterns
1. **Flag** - Koreksi kecil berbentuk channel setelah move besar
2. **Pennant** - Segitiga kecil setelah move besar
3. **Wedge** - Rising wedge (bearish), Falling wedge (bullish)
4. **Triangle** - Ascending (bullish), Descending (bearish), Symmetrical (netral)

### Cara Trading Chart Patterns
1. Identifikasi pattern yang terbentuk
2. Tunggu breakout dengan volume
3. Entry setelah konfirmasi (retest lebih aman)
4. Target = tinggi pattern
5. Stop loss di balik pattern

## Timeframe Analysis

### Multi-Timeframe Approach
1. **Higher TF (D1, W1)** - Tentukan major trend
2. **Middle TF (H4, H1)** - Cari setup entry
3. **Lower TF (M15, M5)** - Fine-tune entry

### Aturan Umum
- Jangan melawan trend di higher timeframe
- Entry searah dengan trend utama
- Lower timeframe untuk timing yang presisi
