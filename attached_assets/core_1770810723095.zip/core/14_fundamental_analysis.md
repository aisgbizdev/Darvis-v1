# Analisis Fundamental untuk Trader

## Mengapa Fundamental Penting?

Analisis fundamental membantu trader memahami:
1. Arah trend jangka panjang
2. Potensi volatilitas dari news event
3. Korelasi antar instrumen
4. Sentimen pasar secara keseluruhan

## Kalender Ekonomi

### High Impact Events (Wajib Perhatikan)
1. **NFP (Non-Farm Payrolls)** - Jumat pertama tiap bulan, 19:30 WIB
2. **FOMC/Fed Decision** - 8x setahun, sangat penting untuk USD
3. **CPI (Inflation)** - Bulanan, pengaruh besar ke kebijakan bank sentral
4. **GDP** - Kuartalan, menunjukkan kesehatan ekonomi
5. **Central Bank Decisions** - ECB, BOE, BOJ, RBA, dll

### Medium Impact Events
- Retail Sales
- PMI (Manufacturing & Services)
- Employment Change
- Trade Balance
- Housing Data

### Cara Membaca Kalender Ekonomi
1. **Actual vs Forecast** - Selisih besar = volatilitas tinggi
2. **Previous** - Untuk melihat trend data
3. **Impact Level** - Fokus pada high impact saat awal

## Data Ekonomi Penting per Negara

### Amerika Serikat (USD)
1. **NFP** - Data pekerjaan, < 100K = bearish, > 200K = bullish
2. **CPI** - Inflasi, tinggi = Fed hawkish = USD bullish
3. **Fed Funds Rate** - Suku bunga, naik = USD bullish
4. **GDP** - Pertumbuhan ekonomi
5. **Unemployment Rate** - Target Fed sekitar 4%

### Eropa (EUR)
1. **ECB Decision** - Kebijakan moneter zona euro
2. **German Data** - Jerman = ekonomi terbesar EU
3. **CPI Eropa** - Target ECB 2%
4. **PMI** - Indikator ekonomi leading

### Inggris (GBP)
1. **BOE Decision** - Kebijakan moneter UK
2. **CPI UK** - Target BOE 2%
3. **Employment** - Data pekerjaan UK

### Jepang (JPY)
1. **BOJ Decision** - Kebijakan ultra-loose
2. **CPI Jepang** - Historically low inflation
3. **Tankan Survey** - Sentimen bisnis

### Australia (AUD)
1. **RBA Decision** - Suku bunga Australia
2. **Employment Change** - Data pekerjaan
3. **China Data** - Australia sangat tergantung China

## Cara Trading News

### Sebelum News
1. Identifikasi event high impact minggu ini
2. Lihat forecast vs previous
3. Tentukan apakah mau trade atau avoid

### Strategi News Trading

#### 1. Avoid Strategy (Paling Aman)
- Close posisi 30 menit sebelum news
- Tunggu 15-30 menit setelah news untuk entry baru
- Cocok untuk trader yang tidak suka volatilitas

#### 2. Straddle Strategy
- Pasang pending order buy & sell di atas/bawah harga current
- News trigger salah satu order
- Risk: Whipsaw, slippage, spread melebar

#### 3. Fade the Spike
- Tunggu spike awal dari news
- Entry berlawanan setelah spike extreme
- Risk: Trend bisa continue

#### 4. Follow the Trend
- Tunggu news release dan initial reaction
- Entry searah momentum jika break level penting
- Lebih aman tapi entry sudah tidak ideal

### Risk Management saat News
1. **Spread melebar** - Bisa 5-10x normal
2. **Slippage** - Order tereksekusi di harga berbeda
3. **Volatilitas extreme** - SL bisa kena dalam hitungan detik
4. **Gap** - Harga loncat tanpa ada harga di tengah

## Korelasi Mata Uang

### Positive Correlation (Bergerak Searah)
- EUR/USD & GBP/USD
- AUD/USD & NZD/USD
- EUR/USD & Gold (umumnya)

### Negative Correlation (Bergerak Berlawanan)
- EUR/USD & USD/CHF
- USD/JPY & Gold
- DXY (Dollar Index) & EUR/USD

### Manfaat Memahami Korelasi
1. Hindari double exposure (jangan long EUR/USD dan GBP/USD bersamaan)
2. Hedging - Buka posisi berlawanan di pair berkorelasi
3. Konfirmasi - Jika EUR/USD naik tapi GBP/USD turun = anomali

## Sentimen Pasar

### Risk-On vs Risk-Off

#### Risk-On (Investor Optimis)
- Saham naik
- Commodity currencies naik (AUD, NZD, CAD)
- JPY dan CHF turun
- Gold cenderung turun

#### Risk-Off (Investor Takut)
- Saham turun
- Safe haven currencies naik (JPY, CHF, USD)
- Commodity currencies turun
- Gold naik

### Indikator Sentimen
1. **VIX (Fear Index)** - Tinggi = fear, rendah = complacency
2. **Bond Yields** - Yield naik = risk-on, yield turun = risk-off
3. **DXY (Dollar Index)** - USD strength/weakness secara keseluruhan

## Tips Analisis Fundamental

1. **Jangan trade semua news** - Fokus pada yang relevan dengan pair yang di-trade
2. **Pahami ekspektasi market** - Bukan nilai absolut, tapi actual vs forecast
3. **Perhatikan context** - Data bagus tapi di tengah krisis = dampak berbeda
4. **Kombinasikan dengan teknikal** - Fundamental untuk arah, teknikal untuk timing
5. **Stay updated** - Ikuti perkembangan berita dan geopolitik
