# Panduan Trading Indices

## Apa itu Stock Index?

Stock index adalah ukuran performa sekelompok saham yang mewakili pasar atau sektor tertentu. Trader bisa trading index tanpa harus beli saham individual.

## Major Global Indices

### Amerika Serikat

#### Dow Jones Industrial Average (US30)
- **Komposisi**: 30 blue-chip companies AS
- **Karakteristik**: Index tertua, price-weighted
- **Jam Trading**: 20:30 - 03:00 WIB (regular session)
- **Perusahaan**: Apple, Microsoft, Boeing, Goldman Sachs, dll
- **Volatilitas**: Medium
- **Average Daily Range**: 200-400 points

#### S&P 500 (US500/SPX500)
- **Komposisi**: 500 perusahaan terbesar AS
- **Karakteristik**: Market-cap weighted, benchmark utama
- **Jam Trading**: 20:30 - 03:00 WIB
- **Volatilitas**: Medium
- **Tips**: Paling representatif untuk US market

#### Nasdaq 100 (NAS100/USTEC)
- **Komposisi**: 100 perusahaan tech terbesar
- **Karakteristik**: Tech-heavy, lebih volatil dari S&P
- **Jam Trading**: 20:30 - 03:00 WIB
- **Perusahaan**: Apple, Microsoft, Amazon, Google, Meta, Tesla, Nvidia
- **Volatilitas**: High
- **Average Daily Range**: 150-300 points
- **Tips**: Sensitif terhadap tech earnings & Fed rate

### Eropa

#### DAX 40 (GER40)
- **Komposisi**: 40 perusahaan terbesar Jerman
- **Karakteristik**: Export-oriented, sensitif ke global trade
- **Jam Trading**: 14:00 - 22:30 WIB
- **Volatilitas**: Medium-High
- **Penggerak**: German data, ECB, China demand

#### FTSE 100 (UK100)
- **Komposisi**: 100 perusahaan terbesar UK
- **Karakteristik**: Commodity & financial heavy
- **Jam Trading**: 14:00 - 22:30 WIB
- **Volatilitas**: Medium
- **Penggerak**: BOE, GBP movement, commodity prices

#### CAC 40 (FRA40)
- **Komposisi**: 40 perusahaan terbesar Prancis
- **Karakteristik**: Luxury & industrial companies
- **Jam Trading**: 14:00 - 22:30 WIB

### Asia

#### Nikkei 225 (JP225)
- **Komposisi**: 225 perusahaan terbesar Jepang
- **Karakteristik**: Inverse correlation dengan JPY
- **Jam Trading**: 07:00 - 13:30 WIB (main session)
- **Volatilitas**: Medium-High
- **Penggerak**: BOJ policy, USD/JPY, US futures

#### Hang Seng (HK50)
- **Komposisi**: 50 perusahaan terbesar Hong Kong
- **Karakteristik**: Gateway ke China, sangat volatil
- **Jam Trading**: 08:30 - 11:00, 12:00 - 15:00 WIB
- **Volatilitas**: Very High
- **Penggerak**: China policy, US-China relations

#### Shanghai Composite / China A50
- **Karakteristik**: Mainland China exposure
- **Volatilitas**: Very High
- **Tips**: Policy-driven, bisa gap besar

### Australia

#### ASX 200 (AUS200)
- **Komposisi**: 200 perusahaan terbesar Australia
- **Karakteristik**: Mining & banking heavy
- **Jam Trading**: 07:00 - 13:00 WIB
- **Penggerak**: RBA, commodity prices, China

## Waktu Trading Optimal

### Session Times (WIB)
1. **Sydney/Tokyo**: 07:00 - 15:00
2. **London/Frankfurt**: 14:00 - 22:30
3. **New York**: 20:30 - 03:00

### Overlap = Volatilitas Tinggi
- Asia-Europe: 14:00 - 15:00 WIB
- Europe-US: 20:30 - 22:30 WIB (TERBAIK)

## Faktor Penggerak Indices

### Makro Factors
1. **Interest Rates** - Rate naik = stock turun (umumnya)
2. **Inflation** - Tinggi = uncertainty = volatility
3. **GDP Growth** - Strong = bullish indices
4. **Employment** - Strong jobs = bullish

### Market-Specific
1. **Earnings Season** - Kuartalan, high volatility
2. **Fed/Central Bank** - Policy decisions
3. **Geopolitical Events** - Wars, elections
4. **Sector Rotation** - Money flow between sectors

### Risk Sentiment
- **Risk-On**: Indices naik, especially growth/tech
- **Risk-Off**: Indices turun, defensive sectors outperform

## Korelasi Antar Indices

### Strong Positive Correlation
- US30, US500, NAS100 (US indices bergerak bersama)
- DAX dan CAC (European indices)
- Hang Seng dan China indices

### Leading Indicators
- US futures overnight = panduan untuk Asia opening
- Asia close = panduan untuk Europe opening
- Nikkei sering follow US close

## Strategi Trading Indices

### Gap Trading
- Indices sering gap di opening
- Trade gap fill atau gap continuation
- Perhatikan overnight news

### News Trading
- FOMC, NFP = high impact untuk US indices
- Earnings = individual stock impact ke index
- Geopolitical = sudden moves

### Trend Following
- Indices cenderung trending
- Moving averages work well
- Pullback ke MA sering jadi entry

### Session Trading
- Trade arah yang sama dengan previous session close
- Reversal sering di opening 30 menit

## Risk Management

### Position Sizing
- Indices bergerak cepat dalam points
- Hitung value per point dengan benar
- 1 lot US30 = biasanya $1/point (bervariasi per broker)

### Stop Loss
- ATR-based stops recommended
- Wider stops untuk overnight holds
- Tight stops untuk intraday

### Avoid
1. Holding saat major news (FOMC, NFP)
2. Trading di low liquidity hours
3. Over-leveraging karena "indices trending"

## Tips Praktis

### Untuk Pemula
1. Mulai dengan US500 (paling stable)
2. Trade saat US session
3. Follow the trend, jangan counter-trend

### Pre-Market Preparation
1. Check overnight US futures
2. Check Asia close
3. Review economic calendar
4. Check VIX level

### Index vs Forex
| Aspect | Indices | Forex |
|--------|---------|-------|
| Volatility | Higher | Medium |
| Trending | Stronger | Variable |
| News Impact | Very High | High |
| Gap Risk | Higher | Lower |
| Session Specific | Yes | Less |
