# Money Management

## Prinsip Dasar Money Management

Money Management adalah cara mengelola modal trading untuk:
1. Melindungi modal dari kerugian besar
2. Memaksimalkan profit dalam jangka panjang
3. Survive di market cukup lama untuk profit

> "Rule No.1: Never lose money. Rule No.2: Never forget Rule No.1." - Warren Buffett

## Risk Per Trade

### The 1-2% Rule
- Risiko maksimal per trade: 1-2% dari total modal
- Contoh: Modal $10,000 → Max risk $100-200 per trade
- Ini berarti jika SL kena, loss maksimal adalah 1-2%

### Mengapa 1-2%?
- 10 loss berturut = hanya 10-20% drawdown
- Modal masih cukup untuk recovery
- Mencegah emotional trading

### Tabel Drawdown & Recovery

| Drawdown | Recovery Needed |
|----------|-----------------|
| 10% | 11% |
| 20% | 25% |
| 30% | 43% |
| 40% | 67% |
| 50% | 100% |
| 60% | 150% |
| 70% | 233% |
| 80% | 400% |
| 90% | 900% |

Kesimpulan: Lebih mudah protect modal daripada recover!

## Position Sizing

### Formula Dasar
```
Lot Size = (Account Risk $) / (SL in Pips × Pip Value)
```

### Contoh Kalkulasi
- Modal: $10,000
- Risk per trade: 2% = $200
- Stop Loss: 50 pips
- Pair: EUR/USD (pip value standard lot = $10)

```
Lot Size = $200 / (50 × $10) = $200 / $500 = 0.4 lot
```

### Position Size Table (2% Risk, $10,000 Account)

| SL (Pips) | Lot Size |
|-----------|----------|
| 20 | 1.0 lot |
| 30 | 0.67 lot |
| 40 | 0.5 lot |
| 50 | 0.4 lot |
| 75 | 0.27 lot |
| 100 | 0.2 lot |

### Tips Position Sizing
1. SELALU hitung position size sebelum entry
2. SL lebih lebar = lot lebih kecil
3. Jangan sesuaikan SL untuk dapat lot lebih besar
4. Gunakan calculator (NM Ai bisa hitung!)

## Risk-Reward Ratio (RRR)

### Apa itu Risk-Reward Ratio?
Perbandingan antara potensi loss dan potensi profit:
- RRR 1:2 = Risk $100, Target $200
- RRR 1:3 = Risk $100, Target $300

### Minimum RRR yang Disarankan
- **Scalping**: Minimal 1:1 (win rate harus tinggi)
- **Day Trading**: Minimal 1:1.5
- **Swing Trading**: Minimal 1:2

### RRR vs Win Rate

| RRR | Min Win Rate untuk Profit |
|-----|---------------------------|
| 1:1 | 51% |
| 1:2 | 34% |
| 1:3 | 26% |
| 1:4 | 21% |

Dengan RRR 1:2, win rate 40% saja sudah profit!

### Contoh Kalkulasi
10 trades dengan RRR 1:2, risk $100 per trade:
- Win 4, Loss 6
- Profit: 4 × $200 = $800
- Loss: 6 × $100 = $600
- Net: +$200 (profit meski win rate hanya 40%!)

## Drawdown Management

### Maximum Drawdown Rules
1. **Daily Drawdown Limit**: 3-5% → Stop trading hari ini
2. **Weekly Drawdown Limit**: 5-10% → Review strategy
3. **Monthly Drawdown Limit**: 10-15% → Pause, evaluate
4. **Account Drawdown Limit**: 20-25% → Major review needed

### Setelah Hit Drawdown Limit
1. Stop trading
2. Review semua trades
3. Identifikasi masalah (strategy? execution? psychology?)
4. Jangan trade sampai masalah teridentifikasi
5. Mulai lagi dengan size lebih kecil

## Portfolio Allocation

### Diversifikasi Risk
- Jangan all-in di satu pair/instrument
- Spread risk ke beberapa trade
- Perhatikan korelasi (jangan double exposure)

### Maximum Exposure
- Total open risk: Max 5-6% account
- Contoh: Maksimal 3 trade @ 2% risk bersamaan
- Atau 6 trade @ 1% risk

### Korelasi yang Perlu Diperhatikan
- EUR/USD dan GBP/USD = positively correlated
- Long keduanya = double exposure ke USD weakness
- Treat sebagai satu trade dari sisi risk

## Compounding

### Kekuatan Compound Returns

Modal $1,000 dengan return bulanan:

| Monthly Return | 1 Year | 3 Years | 5 Years |
|----------------|--------|---------|---------|
| 3% | $1,426 | $2,898 | $5,892 |
| 5% | $1,796 | $5,792 | $18,679 |
| 10% | $3,138 | $30,912 | $304,481 |

### Realistic Expectations
- Consistent 3-5% per bulan = excellent
- 10%+ per bulan = tidak sustainable
- Fokus pada consistency, bukan big gains

### Position Sizing dengan Compound
- Recalculate position size setelah account grow
- $10,000 → 2% = $200 risk
- $12,000 → 2% = $240 risk
- Profit grow secara natural

## Practical Rules

### Before Trading
1. Set risk percentage (1-2%)
2. Calculate max loss amount
3. Determine position size based on SL
4. Check total exposure

### During Trading
1. Stick to predetermined SL
2. Jangan move SL further away
3. Take profit sesuai plan
4. Jangan add ke losing position

### After Trading
1. Log hasil trade
2. Review apakah follow rules
3. Calculate actual risk taken
4. Adjust jika perlu

## Common Mistakes

### 1. Overleveraging
- "Mau cepat kaya" = cepat bangkrut
- High leverage = high risk
- Leverage adalah pedang bermata dua

### 2. Tidak Pakai Stop Loss
- "Nanti juga balik" → Margin call
- SL adalah asuransi
- No SL = gambling

### 3. Moving Stop Loss
- Memindahkan SL lebih jauh saat harga mendekati
- Ini tanda tidak accept loss
- Hasilnya: loss lebih besar

### 4. Averaging Down
- Menambah posisi saat floating loss
- Memperbesar risk
- Bisa works tapi sangat berbahaya

### 5. Martingale
- Double lot setelah loss
- Secara matematis akan blow up
- JANGAN PERNAH

## Golden Rules

1. **Never risk more than you can afford to lose**
2. **Capital preservation first, profit second**
3. **Consistency beats intensity**
4. **Plan your trade, trade your plan**
5. **Let winners run, cut losers short**
