# FAQ Bappebti & Regulasi Trading Indonesia

## Apa itu Bappebti?

**Badan Pengawas Perdagangan Berjangka Komoditi (Bappebti)** adalah lembaga pemerintah di bawah Kementerian Perdagangan RI yang bertugas mengawasi perdagangan berjangka dan derivatif di Indonesia.

### Fungsi Bappebti
1. Mengatur dan mengawasi perdagangan berjangka
2. Melindungi kepentingan nasabah
3. Memberikan izin kepada pelaku usaha
4. Menegakkan hukum di bidang perdagangan berjangka

## Jenis Perizinan Bappebti

### 1. Pialang Berjangka (Broker)
- Izin untuk menjalankan usaha sebagai perantara trading
- Harus memenuhi modal minimum
- Wajib laporan keuangan berkala

### 2. Pedagang Berjangka
- Izin untuk trading dengan modal sendiri
- Tidak boleh menerima dana nasabah

### 3. Penasehat Berjangka
- Izin untuk memberikan nasihat/edukasi trading
- Tidak boleh menerima dana untuk trading

## Sistem Perdagangan Alternatif (SPA)

### Apa itu SPA?
SPA adalah sistem trading yang diselenggarakan oleh Pialang Berjangka untuk memfasilitasi transaksi derivatif over-the-counter (OTC) seperti forex dan CFD.

### Ciri-ciri SPA Legal
1. Diselenggarakan oleh broker berizin Bappebti
2. Dana nasabah di segregated account bank dalam negeri
3. Ada perjanjian tertulis dengan nasabah
4. Laporan transaksi tersedia
5. Terdaftar di sistem Bappebti

### Produk yang Diperdagangkan di SPA
- Forex (pasangan mata uang)
- Index
- Komoditas (gold, silver, oil)
- CFD saham luar negeri

## Perlindungan Nasabah

### Hak Nasabah
1. Mendapat informasi yang jelas tentang risiko
2. Dana disimpan di segregated account
3. Menerima laporan transaksi dan posisi
4. Mengajukan keluhan dan mendapat penyelesaian
5. Menarik dana kapan saja (sesuai prosedur)

### Segregated Account
- Dana nasabah WAJIB terpisah dari dana broker
- Disimpan di bank dalam negeri yang ditunjuk
- Broker tidak boleh menggunakan dana nasabah

### Jika Ada Masalah
1. Ajukan keluhan ke broker terlebih dahulu
2. Jika tidak terselesaikan, lapor ke Bappebti
3. Bisa melalui: pengaduan@bappebti.go.id
4. Atau datang langsung ke kantor Bappebti

## Broker Legal vs Ilegal

### Ciri Broker Legal (Berizin Bappebti)
1. Tercantum di website Bappebti
2. Memiliki nomor izin yang bisa diverifikasi
3. Kantor fisik di Indonesia
4. Segregated account di bank lokal
5. Dokumen perjanjian lengkap
6. Customer service responsif

### Ciri Broker Ilegal
1. Tidak terdaftar di Bappebti
2. Server di luar negeri tanpa izin
3. Iming-iming profit pasti/besar
4. Tidak ada segregated account
5. Sulit/tidak bisa withdraw
6. No customer support lokal

### Cara Cek Legalitas Broker
1. Buka website Bappebti: www.bappebti.go.id
2. Menu: Layanan Publik → Daftar Pialang
3. Cari nama broker
4. Periksa status izin (aktif/dicabut)

### Daftar 5 Broker Partner Newsmaker (Legal & Terpercaya)
1. **RFB (PT Rifan Financindo Berjangka)**
2. **EWF (PT Equityworld Futures)**
3. **SGB (PT Solid Gold Berjangka)**
4. **KPF (PT Kontak Perkasa Futures)**
5. **BPF (PT Bestprofit Futures)**

Semua broker partner Newsmaker sudah terverifikasi legal dan berizin Bappebti.

## FAQ Umum

### Q: Apakah trading forex legal di Indonesia?
**A:** Ya, legal jika melalui broker yang berizin Bappebti dan menggunakan Sistem Perdagangan Alternatif (SPA).

### Q: Berapa minimal deposit untuk mulai trading?
**A:** Bervariasi per broker, umumnya mulai dari Rp 3-10 juta. Namun disarankan modal yang lebih besar untuk manajemen risiko yang baik.

### Q: Apakah profit trading kena pajak?
**A:** Ya, profit trading termasuk penghasilan yang dikenakan pajak sesuai peraturan perpajakan yang berlaku.

### Q: Bagaimana jika broker tutup/bangkrut?
**A:** Dana nasabah di segregated account tetap milik nasabah. Bappebti akan memfasilitasi proses pengembalian dana.

### Q: Apakah bisa trading 24 jam?
**A:** Forex dan beberapa instrumen bisa trading 24 jam selama hari kerja (Senin-Jumat). Sabtu-Minggu market tutup.

### Q: Apa bedanya trading forex dan investasi bodong?
**A:**
- **Trading Forex Legal**: Ada risiko loss, tidak ada jaminan profit, broker berizin, dana di segregated account
- **Investasi Bodong**: Janji profit pasti, skema Ponzi, tidak berizin, dana tidak jelas penggunaannya

### Q: Bagaimana cara mengadu ke Bappebti?
**A:**
1. Siapkan bukti-bukti (dokumen, screenshot, rekaman)
2. Tulis kronologi kejadian
3. Kirim ke pengaduan@bappebti.go.id
4. Atau datang ke Kantor Bappebti Jakarta
5. Bisa juga melalui call center: 021-31906479

### Q: Apakah ada lembaga penjamin seperti LPS untuk trading?
**A:** Tidak ada penjaminan seperti LPS perbankan. Inilah mengapa penting memilih broker legal dan memahami risiko trading.

## Peraturan Penting

### UU No. 32 Tahun 1997
Tentang Perdagangan Berjangka Komoditi (diubah dengan UU No. 10 Tahun 2011)

### PP No. 9 Tahun 1999
Tentang Penyelenggaraan Perdagangan Berjangka Komoditi

### Peraturan Kepala Bappebti
Berbagai peraturan teknis tentang:
- Perizinan
- Modal minimum
- Segregated account
- Pelaporan
- Sanksi

## Tips Aman Trading

1. **Pilih broker legal** - Cek di website Bappebti
2. **Baca perjanjian** - Pahami hak dan kewajiban
3. **Kelola risiko** - Jangan invest lebih dari yang siap hilang
4. **Belajar dulu** - Demo account sebelum real
5. **Waspada penipuan** - Tidak ada profit pasti
6. **Simpan bukti** - Dokumentasi semua transaksi
7. **Edukasi terus** - Ikuti perkembangan regulasi
