# Glossary Istilah Trading

## A

**Ask Price** - Harga yang ditawarkan seller/broker untuk menjual. Ini harga yang kita bayar saat BUY.

**ATR (Average True Range)** - Indikator yang mengukur volatilitas rata-rata dalam periode tertentu.

**Averaging Down** - Menambah posisi buy saat harga turun untuk menurunkan average price. Berisiko tinggi.

## B

**Balance** - Total dana di akun trading sebelum memperhitungkan floating profit/loss.

**Base Currency** - Mata uang pertama dalam pair. EUR/USD = EUR adalah base currency.

**Bear/Bearish** - Kondisi market turun atau ekspektasi harga akan turun.

**Bid Price** - Harga yang ditawarkan buyer untuk membeli. Ini harga yang kita dapat saat SELL.

**Breakout** - Saat harga menembus level support atau resistance.

**Broker** - Perantara yang memfasilitasi transaksi trading.

**Bull/Bullish** - Kondisi market naik atau ekspektasi harga akan naik.

**Buy Limit** - Order pending untuk buy di bawah harga saat ini.

**Buy Stop** - Order pending untuk buy di atas harga saat ini.

## C

**Candlestick** - Representasi visual pergerakan harga yang menunjukkan open, high, low, close.

**CFD (Contract for Difference)** - Kontrak derivatif yang memungkinkan trading tanpa memiliki aset underlying.

**Commission** - Biaya yang dikenakan broker per transaksi.

**Consolidation** - Periode dimana harga bergerak sideways dalam range tertentu.

**Cross Rate** - Pair mata uang yang tidak melibatkan USD. Contoh: EUR/GBP, GBP/JPY.

**Currency Pair** - Pasangan dua mata uang yang diperdagangkan. Format: BASE/QUOTE.

## D

**Day Trading** - Style trading yang membuka dan menutup posisi dalam hari yang sama.

**Divergence** - Ketidaksesuaian antara pergerakan harga dan indikator. Sinyal potensi reversal.

**Drawdown** - Penurunan dari titik tertinggi modal ke titik terendah. Ukuran risiko.

## E

**ECN (Electronic Communication Network)** - Sistem trading yang menghubungkan trader langsung ke liquidity provider.

**Entry** - Titik masuk posisi trading.

**Equity** - Balance + floating profit/loss. Nilai akun real-time.

**Exit** - Titik keluar dari posisi trading.

**Exotic Pairs** - Pair yang melibatkan mata uang negara berkembang. Contoh: USD/TRY, USD/ZAR.

## F

**Fibonacci** - Tool analisis teknikal berdasarkan deret Fibonacci untuk mencari level retracement dan extension.

**Fill** - Eksekusi order trading.

**Floating Profit/Loss** - Profit atau loss yang belum direalisasi dari posisi yang masih terbuka.

**Forex (Foreign Exchange)** - Pasar pertukaran mata uang asing.

**Fundamental Analysis** - Analisis berdasarkan data ekonomi, berita, dan kebijakan.

## G

**Gap** - Celah harga antara close candle sebelumnya dan open candle berikutnya.

**GTC (Good Till Cancelled)** - Order yang tetap aktif sampai dieksekusi atau dibatalkan manual.

## H

**Hedge/Hedging** - Strategi membuka posisi berlawanan untuk mengurangi risiko.

**High** - Harga tertinggi dalam periode tertentu.

## I

**Index/Indices** - Instrumen yang mewakili kumpulan saham. Contoh: S&P 500, Dow Jones.

## L

**Leverage** - Kemampuan mengontrol posisi besar dengan modal kecil. 1:100 = modal $100 bisa buka posisi $10,000.

**Limit Order** - Order untuk buy/sell di harga tertentu atau lebih baik.

**Liquidity** - Kemudahan untuk membeli atau menjual tanpa mempengaruhi harga signifikan.

**Long** - Posisi buy, mengharapkan harga naik.

**Lot** - Satuan ukuran transaksi trading.
- Standard lot = 100,000 unit
- Mini lot = 10,000 unit
- Micro lot = 1,000 unit

**Low** - Harga terendah dalam periode tertentu.

## M

**Margin** - Dana yang dibutuhkan sebagai jaminan untuk membuka posisi.

**Margin Call** - Peringatan dari broker bahwa margin tidak cukup. Perlu deposit atau close posisi.

**Market Order** - Order untuk buy/sell di harga pasar saat ini.

**Major Pairs** - Pair mata uang yang paling liquid, semua melibatkan USD.

## O

**Open** - Harga pembukaan dalam periode tertentu.

**Order** - Instruksi untuk melakukan transaksi trading.

**Overbought** - Kondisi dimana harga dianggap sudah terlalu tinggi (RSI > 70).

**Overnight** - Posisi yang dibiarkan terbuka melewati pergantian hari.

**Oversold** - Kondisi dimana harga dianggap sudah terlalu rendah (RSI < 30).

## P

**Pending Order** - Order yang akan tereksekusi jika harga menyentuh level tertentu.

**Pip** - Pergerakan harga terkecil. Untuk mayoritas pair = 0.0001. Untuk JPY pairs = 0.01.

**Pivot Point** - Level support dan resistance yang dihitung dari high, low, close periode sebelumnya.

**Position** - Trade yang sedang terbuka.

**Price Action** - Metode analisis berdasarkan pergerakan harga tanpa indikator.

## Q

**Quote Currency** - Mata uang kedua dalam pair. EUR/USD = USD adalah quote currency.

## R

**Range** - Selisih antara high dan low dalam periode tertentu.

**Resistance** - Level harga dimana selling pressure cenderung muncul.

**Retracement** - Pergerakan harga berlawanan dengan trend utama sementara.

**Reversal** - Perubahan arah trend.

**Risk Management** - Pengelolaan risiko dalam trading.

**Risk/Reward Ratio** - Perbandingan potensi loss vs potensi profit.

## S

**Scalping** - Style trading yang mengambil profit kecil dari pergerakan harga cepat.

**Sell Limit** - Order pending untuk sell di atas harga saat ini.

**Sell Stop** - Order pending untuk sell di bawah harga saat ini.

**Short** - Posisi sell, mengharapkan harga turun.

**Slippage** - Perbedaan antara harga yang diharapkan dan harga eksekusi aktual.

**Spread** - Selisih antara bid dan ask price. Biaya trading.

**Stop Loss (SL)** - Order untuk menutup posisi di harga tertentu untuk membatasi kerugian.

**Support** - Level harga dimana buying pressure cenderung muncul.

**Swap** - Biaya/credit untuk posisi yang dibiarkan overnight.

**Swing Trading** - Style trading yang menahan posisi beberapa hari sampai minggu.

## T

**Take Profit (TP)** - Order untuk menutup posisi di harga tertentu untuk mengamankan profit.

**Technical Analysis** - Analisis berdasarkan chart, pattern, dan indikator.

**Tick** - Pergerakan harga terkecil.

**Timeframe** - Periode waktu setiap candlestick. M1, M5, H1, D1, W1, dll.

**Trailing Stop** - Stop loss yang bergerak mengikuti harga saat profit.

**Trend** - Arah pergerakan harga secara umum. Uptrend, Downtrend, Sideways.

## V

**Volatility** - Ukuran seberapa besar pergerakan harga.

**Volume** - Jumlah transaksi dalam periode tertentu.

## W

**Whipsaw** - Pergerakan harga yang cepat naik-turun, sering menyebabkan stop loss terkena.

## Singkatan Penting

- **ATH** - All Time High
- **ATL** - All Time Low
- **BE** - Break Even
- **DCA** - Dollar Cost Averaging
- **FOMO** - Fear Of Missing Out
- **HOD** - High Of Day
- **LOD** - Low Of Day
- **PA** - Price Action
- **RR** - Risk Reward
- **S/R** - Support/Resistance
- **SL** - Stop Loss
- **TP** - Take Profit
