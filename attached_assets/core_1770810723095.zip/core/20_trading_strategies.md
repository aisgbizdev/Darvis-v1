# Trading Strategies

## Kategori Trading Berdasarkan Timeframe

### 1. Scalping
- **Durasi**: Detik sampai menit
- **Target**: 5-15 pips per trade
- **Frequency**: 10-50+ trades per hari
- **Timeframe**: M1, M5
- **Pro**: Tidak overnight risk, banyak peluang
- **Con**: Stress tinggi, spread impact besar, butuh fokus penuh

### 2. Day Trading
- **Durasi**: Menit sampai jam
- **Target**: 20-50 pips per trade
- **Frequency**: 1-5 trades per hari
- **Timeframe**: M15, M30, H1
- **Pro**: Tidak overnight risk, cukup waktu untuk analisa
- **Con**: Butuh screen time, news impact

### 3. Swing Trading
- **Durasi**: Hari sampai minggu
- **Target**: 100-300 pips per trade
- **Frequency**: 2-10 trades per bulan
- **Timeframe**: H4, D1
- **Pro**: Tidak perlu pantau terus, bigger moves
- **Con**: Overnight/weekend risk, swap cost

### 4. Position Trading
- **Durasi**: Minggu sampai bulan
- **Target**: 500+ pips per trade
- **Frequency**: 1-3 trades per bulan
- **Timeframe**: D1, W1
- **Pro**: Set and forget, catch major trends
- **Con**: Butuh modal besar untuk SL lebar, patience

## Strategi Populer

### 1. Trend Following

#### Konsep
- "Trend is your friend"
- Trade searah trend utama
- Tunggu pullback untuk entry

#### Setup
1. Identifikasi trend di higher timeframe (D1/H4)
2. Tunggu pullback ke area value (MA, S/R)
3. Entry saat ada reversal signal di lower timeframe
4. SL di bawah swing low/high
5. TP di next resistance/support atau trail

#### Indikator yang Cocok
- Moving Averages (EMA 20, 50, 200)
- ADX (trend strength)
- Trendlines

#### Tips
- Jangan counter-trend
- Pullback ke MA sering jadi entry bagus
- Trend bisa berlanjut lebih lama dari yang diperkirakan

### 2. Breakout Trading

#### Konsep
- Trade saat harga break level penting
- Momentum besar setelah breakout
- Catch the move early

#### Setup
1. Identifikasi consolidation/range
2. Mark support dan resistance level
3. Tunggu candle close di luar range
4. Entry dengan konfirmasi volume (jika tersedia)
5. SL di dalam range
6. TP = lebar range (measured move)

#### Level untuk Breakout
- Horizontal S/R
- Trendlines
- Chart patterns (triangle, flag, wedge)
- Previous high/low

#### Tips
- False breakout sangat umum
- Tunggu candle close, bukan shadow
- Retest setelah breakout = entry lebih aman
- Asian session breakout di London open

### 3. Reversal Trading

#### Konsep
- Trade perubahan arah trend
- Catch new trend early
- Higher risk, higher reward

#### Setup
1. Identifikasi trend yang exhausted
2. Cari divergence (RSI/MACD vs Price)
3. Wait for reversal candlestick pattern
4. Entry setelah konfirmasi
5. Tight SL di balik swing
6. TP di next major level

#### Konfirmasi Reversal
- Double/Triple top/bottom
- Head & Shoulders
- Divergence
- Candlestick patterns (engulfing, pin bar)
- Break of trendline

#### Tips
- Jangan catch falling knife
- Butuh multiple confirmation
- Start dengan position kecil
- Add jika reversal terkonfirmasi

### 4. Range Trading

#### Konsep
- Trade dalam sideways market
- Buy di support, sell di resistance
- Mean reversion approach

#### Setup
1. Identifikasi clear range
2. Mark support dan resistance
3. Buy di support dengan bullish signal
4. Sell di resistance dengan bearish signal
5. SL di luar range
6. TP di opposite side of range

#### Indikator yang Cocok
- RSI (overbought/oversold)
- Bollinger Bands
- Stochastic

#### Tips
- Tidak semua market ranging - identify dulu
- Breakout bisa terjadi kapan saja
- Risk di dekat boundary of range
- Asian session sering ranging

### 5. Support/Resistance Strategy

#### Konsep
- S/R adalah area dimana harga react
- Buy di support, sell di resistance
- Simple tapi effective

#### Setup
1. Mark major S/R levels dari higher TF
2. Tunggu harga approach level
3. Wait for price action signal di level
4. Entry dengan konfirmasi
5. SL di balik level
6. TP di next level

#### Cara Menggambar S/R
- Use body, not shadows
- Zone, bukan garis tipis
- Semakin banyak touch, semakin valid
- Recent levels lebih relevan

### 6. Moving Average Strategy

#### Simple MA Crossover
- Buy: Fast MA cross up Slow MA
- Sell: Fast MA cross down Slow MA
- Popular combo: EMA 9/21, EMA 20/50

#### MA Bounce Strategy
- Trend up: Buy saat pullback ke MA
- Trend down: Sell saat rally ke MA
- Popular MA: EMA 20, EMA 50

#### MA Stack
- Uptrend: Price > MA20 > MA50 > MA200
- Downtrend: Price < MA20 < MA50 < MA200
- Only trade when MAs are stacked

### 7. Price Action Trading

#### Konsep
- Trade based on candlestick patterns
- No indicators or minimal indicators
- Pure price movement

#### Key Patterns
1. **Pin Bar** - Rejection candle, long shadow
2. **Engulfing** - Candle menelan candle sebelumnya
3. **Inside Bar** - Candle dalam range candle sebelumnya
4. **Outside Bar** - Candle range melebihi candle sebelumnya

#### Context is King
- Pattern di S/R level lebih valid
- Pattern dengan trend lebih valid
- Pattern di higher TF lebih kuat

## Memilih Strategy yang Tepat

### Pertimbangan
1. **Time Available** - Scalping butuh full-time
2. **Personality** - Sabar? Swing. Tidak sabar? Day trading
3. **Capital** - Modal kecil = higher frequency
4. **Risk Tolerance** - Conservative = trend following

### Testing Strategy
1. Backtest minimal 100 trades
2. Forward test di demo 1-3 bulan
3. Review win rate, RRR, max drawdown
4. Adjust parameter jika perlu
5. Live trading dengan size kecil

## Strategy Tidak Bekerja?

### Check These First
1. Apakah market condition cocok? (trending vs ranging)
2. Apakah execution sesuai rules?
3. Apakah psychology mengganggu?
4. Apakah risk management dipatuhi?

### When to Change Strategy
- Setelah 50+ trades dengan hasil konsisten buruk
- Market structure berubah signifikan
- Tidak cocok dengan lifestyle

### When NOT to Change Strategy
- Setelah beberapa loss (normal)
- Tanpa cukup sample size
- Karena lihat strategi "lebih bagus"
