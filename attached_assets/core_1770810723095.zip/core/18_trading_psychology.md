# Trading Psychology

## Mengapa Psikologi Penting?

Trading adalah 80% psychology, 20% strategy. Banyak trader punya strategy bagus tapi tetap loss karena tidak bisa mengontrol emosi.

## Emosi Utama dalam Trading

### 1. Fear (Ketakutan)

#### Manifestasi Fear
- Takut entry padahal setup sudah valid
- Close profit terlalu cepat karena takut reversal
- Tidak mau cut loss karena takut "realize loss"
- Freeze saat market bergerak cepat

#### Dampak Fear
- Missed opportunities (tidak entry)
- Profit kecil (close terlalu cepat)
- Loss besar (tidak cut loss)

#### Cara Mengatasi Fear
1. Gunakan position size yang nyaman
2. Terima bahwa loss adalah bagian dari trading
3. Fokus pada proses, bukan hasil per trade
4. Backtest strategy untuk build confidence
5. Journaling untuk identifikasi pola fear

### 2. Greed (Keserakahan)

#### Manifestasi Greed
- Overleveraging untuk cari profit besar
- Tidak take profit, berharap harga terus naik
- Menambah posisi di trade yang sudah profit (pyramiding tanpa plan)
- Trading tanpa stop loss

#### Dampak Greed
- Profit berubah jadi loss
- Margin call karena overleveraging
- Akun blow up

#### Cara Mengatasi Greed
1. Set target profit realistis
2. Take partial profit
3. Patuhi risk management (max 1-2% per trade)
4. Ingat: market akan selalu ada besok
5. Fokus pada consistency, bukan home run

### 3. FOMO (Fear of Missing Out)

#### Manifestasi FOMO
- Entry terlambat karena lihat harga sudah naik
- Chase the market tanpa setup yang jelas
- Masuk trade karena lihat orang lain profit
- Tidak sabar menunggu setup

#### Dampak FOMO
- Entry di harga buruk
- Stop loss kena karena entry terlambat
- Tidak ada edge karena tidak ada plan

#### Cara Mengatasi FOMO
1. Ada ribuan peluang trading - tidak perlu semua diambil
2. Buat trading plan dan patuhi
3. If in doubt, stay out
4. Lebih baik miss trade daripada bad trade
5. Market selalu kasih peluang baru

### 4. Revenge Trading

#### Manifestasi Revenge Trading
- Langsung entry setelah loss untuk "balas dendam"
- Double lot untuk recover loss
- Trading tanpa setup setelah loss
- Tidak bisa terima loss, harus balik modal hari ini

#### Dampak Revenge Trading
- Loss berlipat-lipat
- Emotional spiral
- Account blow up

#### Cara Mengatasi Revenge Trading
1. Set daily loss limit - stop trading jika tercapai
2. Setelah loss, ambil break 15-30 menit
3. Review trade yang loss sebelum trade lagi
4. Ingat: recover 50% loss butuh 100% gain
5. Besok adalah hari baru

### 5. Overconfidence

#### Manifestasi Overconfidence
- Setelah winning streak, naikkan lot drastis
- Merasa sudah "master" setelah beberapa trade profit
- Tidak follow trading plan karena merasa tahu lebih baik
- Ignore risk management

#### Dampak Overconfidence
- Satu loss besar hapus semua profit
- Complacency - tidak belajar lagi
- Risk management diabaikan

#### Cara Mengatasi Overconfidence
1. Treat every trade the same
2. Stick to position sizing rules
3. Market bisa humble siapapun
4. Review losing trades juga, bukan hanya winning

## Mindset Trader Sukses

### 1. Probabilistic Thinking
- Tidak ada trade yang pasti profit
- Win rate 50-60% sudah bagus
- Fokus pada edge jangka panjang
- Accept uncertainty

### 2. Process Over Outcome
- Trade bagus bisa loss, trade buruk bisa profit
- Nilai keputusan, bukan hasil
- Konsistensi proses = konsistensi hasil

### 3. Long-Term Perspective
- Trading adalah marathon, bukan sprint
- Compound returns over time
- Protect capital first, profit second

### 4. Continuous Learning
- Market selalu berubah
- Tidak ada holy grail
- Review dan improve terus

### 5. Detachment from Money
- Lihat angka sebagai points, bukan uang
- Jangan trade dengan "scared money"
- Risk only what you can afford to lose

## Praktik untuk Mental yang Kuat

### 1. Trading Journal
Catat setiap trade:
- Setup dan alasan entry
- Emosi saat entry dan exit
- Apa yang bisa diperbaiki
- Screenshot chart

### 2. Pre-Trade Checklist
Sebelum entry, tanya:
- Apakah ini sesuai trading plan?
- Apakah risk/reward masuk akal?
- Apakah saya dalam kondisi emosi netral?
- Apakah saya siap jika trade ini loss?

### 3. Post-Trade Review
Setelah trade:
- Apakah saya follow plan?
- Apa yang saya rasakan?
- Apa yang bisa diperbaiki?

### 4. Daily Routine
- Set waktu trading yang konsisten
- Jangan trade saat lelah/stress
- Physical health affects mental health
- Take breaks

### 5. Maximum Loss Rules
- Daily max loss: Stop trading hari ini
- Weekly max loss: Review strategy
- Account drawdown limit: Pause trading, review

## Red Flags: Kapan TIDAK Boleh Trading

1. Setelah loss besar dan masih emosional
2. Saat stress dari masalah non-trading
3. Saat kurang tidur atau sakit
4. Saat "harus" profit untuk bayar sesuatu
5. Saat merasa "pasti profit"
6. Setelah minum alkohol
7. Saat tidak punya trading plan

## Cognitive Biases dalam Trading

Bias kognitif adalah "jebakan pikiran" yang mempengaruhi keputusan trading secara tidak rasional.

### 1. Loss Aversion (Keengganan Rugi)
**Definisi:** Ketakutan terhadap kerugian lebih besar daripada keinginan memperoleh keuntungan.

**Dampak:**
- Menahan posisi rugi terlalu lama, berharap harga kembali
- Terlalu cepat mengambil profit karena takut berubah jadi loss
- Tidak mau cut loss padahal setup sudah invalid

**Solusi:**
- Set stop loss SEBELUM entry dan patuhi
- Ingat: cut loss kecil hari ini mencegah loss besar besok
- Lihat loss sebagai "biaya bisnis" trading

### 2. Herding Behaviour (Perilaku Ikut-ikutan)
**Definisi:** Kecenderungan mengikuti keputusan mayoritas pasar tanpa analisis independen.

**Dampak:**
- Membentuk tren harga yang ekstrem (bubble)
- Gelembung harga yang pecah menjadi koreksi mendadak
- Entry di puncak, exit di dasar

**Solusi:**
- Buat analisis sendiri sebelum lihat opini orang lain
- "Be fearful when others are greedy, greedy when others are fearful"
- Jangan entry hanya karena semua orang bilang bullish/bearish

### 3. Anchoring (Jangkar Mental)
**Definisi:** Terpaku pada informasi awal atau referensi harga tertentu sebagai acuan keputusan.

**Dampak:**
- Sulit beradaptasi dengan perubahan tren atau sinyal baru
- "Harga pasti balik ke level X" padahal market sudah berubah
- Tidak mau admit wrong karena sudah "commit" ke analisis awal

**Solusi:**
- Update analisis secara berkala dengan data terbaru
- Harga tidak "harus" kemana-mana
- Fokus pada what IS happening, bukan what SHOULD happen

### 4. Recency Bias (Bias Kekinian)
**Definisi:** Lebih mempercayai informasi atau tren terbaru daripada data historis jangka panjang.

**Dampak:**
- Membuat keputusan reaktif berdasarkan berita/sentimen sesaat
- Overreact terhadap pergerakan harga jangka pendek
- Mengabaikan trend jangka panjang yang lebih signifikan

**Solusi:**
- Selalu lihat multiple timeframe (daily, weekly, monthly)
- Jangan trading berdasarkan berita breaking saja
- Evaluasi apakah informasi ini mengubah BIG PICTURE atau tidak

### 5. Confirmation Bias (Bias Konfirmasi)
**Definisi:** Hanya mencari dan percaya pada informasi yang mendukung keyakinan atau analisis yang sudah dibuat.

**Dampak:**
- Mengabaikan data atau sinyal yang bertentangan
- Meningkatkan risiko kerugian karena blind spot
- Tidak mau review atau koreksi analisis yang salah

**Solusi:**
- Aktif cari alasan MENGAPA analisis Anda bisa SALAH
- Dengarkan pendapat yang berlawanan
- Set invalidation point SEBELUM entry

### 6. Gambler's Fallacy (Kekeliruan Penjudi)
**Definisi:** Percaya bahwa hasil sebelumnya mempengaruhi probabilitas hasil berikutnya dalam kejadian independen.

**Dampak:**
- "Sudah loss 5x, pasti yang ke-6 profit" → double down
- "Sudah profit 5x berturut, saatnya all-in" → overleveraging
- Tidak memahami bahwa setiap trade adalah event independen

**Solusi:**
- Setiap trade adalah probabilitas baru
- Winning/losing streak tidak mengubah edge sistem
- Stick to position sizing rules ALWAYS

## Quotes untuk Diingat

> "The goal of a successful trader is to make the best trades. Money is secondary." - Alexander Elder

> "In trading, the impossible happens about twice a year." - Henri Pittier

> "Risk comes from not knowing what you're doing." - Warren Buffett

> "It's not about being right or wrong, but about how much money you make when you're right and how much you lose when you're wrong." - George Soros
