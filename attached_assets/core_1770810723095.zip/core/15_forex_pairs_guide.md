# Panduan Forex Pairs

## Kategori Currency Pairs

### Major Pairs (Likuiditas Tertinggi)
Semua pair yang melibatkan USD:
1. EUR/USD - "Euro"
2. GBP/USD - "Cable"
3. USD/JPY - "Gopher"
4. USD/CHF - "Swissy"
5. AUD/USD - "Aussie"
6. USD/CAD - "Loonie"
7. NZD/USD - "Kiwi"

### Cross Pairs (Tanpa USD)
1. EUR/GBP - "Euro-Pound"
2. EUR/JPY - "Euro-Yen"
3. GBP/JPY - "Guppy" atau "Dragon"
4. EUR/AUD
5. GBP/AUD
6. AUD/JPY
7. CHF/JPY

### Exotic Pairs (Volatilitas Tinggi, Spread Besar)
- USD/TRY (Turkish Lira)
- USD/ZAR (South African Rand)
- USD/MXN (Mexican Peso)
- USD/SGD (Singapore Dollar)

## Karakteristik Major Pairs

### EUR/USD (Euro vs US Dollar)
- **Volume**: Pair paling liquid di dunia (28% volume forex)
- **Spread**: Paling kecil, biasanya 0.1-1 pip
- **Karakteristik**: Smooth movement, bagus untuk pemula
- **Jam Aktif**: London & New York session (14:00-23:00 WIB)
- **Penggerak**: ECB, Fed, NFP, CPI EU/US, German data
- **Average Daily Range**: 80-100 pips

### GBP/USD (British Pound vs US Dollar)
- **Volume**: Pair ke-3 paling liquid
- **Spread**: 1-2 pips
- **Karakteristik**: Volatil, movement besar, bisa tricky
- **Jam Aktif**: London session (14:00-22:00 WIB)
- **Penggerak**: BOE, Fed, UK data, Brexit news
- **Average Daily Range**: 100-150 pips
- **Tips**: Hati-hati false breakout, news UK sangat impact

### USD/JPY (US Dollar vs Japanese Yen)
- **Volume**: Pair ke-2 paling liquid
- **Spread**: 0.5-1.5 pips
- **Karakteristik**: Trending pair, korelasi dengan US yields
- **Jam Aktif**: Asian & US session
- **Penggerak**: BOJ, Fed, US Treasury yields, risk sentiment
- **Average Daily Range**: 70-100 pips
- **Tips**: Safe haven saat risk-off, perhatikan intervensi BOJ

### AUD/USD (Australian Dollar vs US Dollar)
- **Karakteristik**: Commodity currency, korelasi dengan China & Gold
- **Spread**: 1-2 pips
- **Jam Aktif**: Asian & early London session
- **Penggerak**: RBA, China data, commodity prices, risk sentiment
- **Average Daily Range**: 60-80 pips
- **Tips**: Risk-on currency, turun saat market takut

### USD/CAD (US Dollar vs Canadian Dollar)
- **Karakteristik**: Korelasi dengan harga Oil (Canada eksportir oil)
- **Spread**: 1.5-2.5 pips
- **Jam Aktif**: US session
- **Penggerak**: Oil prices, BOC, Fed, employment Canada
- **Average Daily Range**: 60-80 pips
- **Tips**: Cek harga oil sebelum trade

### USD/CHF (US Dollar vs Swiss Franc)
- **Karakteristik**: Safe haven, inverse EUR/USD
- **Spread**: 1-2 pips
- **Jam Aktif**: London session
- **Penggerak**: SNB, risk sentiment, geopolitik
- **Average Daily Range**: 50-70 pips
- **Tips**: CHF menguat saat krisis/ketidakpastian

### NZD/USD (New Zealand Dollar vs US Dollar)
- **Karakteristik**: Mirip AUD tapi lebih volatil, dairy prices matter
- **Spread**: 1.5-2.5 pips
- **Jam Aktif**: Asian session
- **Penggerak**: RBNZ, dairy prices, risk sentiment
- **Average Daily Range**: 50-70 pips

## Karakteristik Cross Pairs Populer

### EUR/GBP
- **Karakteristik**: Range-bound, cocok untuk ranging strategy
- **Spread**: 1-2 pips
- **Penggerak**: ECB vs BOE policy divergence
- **Tips**: Perhatikan relative strength EUR vs GBP

### GBP/JPY (The Dragon)
- **Karakteristik**: SANGAT VOLATIL, bisa bergerak 200+ pips/hari
- **Spread**: 2-4 pips
- **Penggerak**: Risk sentiment, BOE, BOJ
- **Tips**: Bukan untuk pemula, butuh SL lebih lebar
- **Risk**: Bisa wipe out account jika tidak hati-hati

### EUR/JPY
- **Karakteristik**: Volatil tapi lebih terkontrol dari GBP/JPY
- **Spread**: 1.5-3 pips
- **Penggerak**: Risk sentiment, ECB, BOJ

## Waktu Trading Optimal

### Session Times (WIB)
1. **Sydney**: 05:00 - 14:00
2. **Tokyo**: 07:00 - 16:00
3. **London**: 14:00 - 23:00
4. **New York**: 19:00 - 04:00

### Overlap Sessions (Paling Aktif)
1. **London-Tokyo**: 14:00 - 16:00 WIB
2. **London-New York**: 19:00 - 23:00 WIB (TERBAIK)

### Pair vs Session

| Pair | Best Session |
|------|-------------|
| EUR/USD | London, NY |
| GBP/USD | London |
| USD/JPY | Tokyo, NY |
| AUD/USD | Tokyo, London |
| EUR/JPY | London |
| GBP/JPY | London |

## Tips Memilih Pair

### Untuk Pemula
1. Mulai dengan EUR/USD (paling stabil, spread kecil)
2. Hindari exotic pairs
3. Hindari cross pairs volatil seperti GBP/JPY

### Untuk Scalping
- EUR/USD, USD/JPY (spread kecil)
- Hindari saat news

### Untuk Swing Trading
- Semua major pairs
- Perhatikan fundamental

### Yang Perlu Diperhatikan
1. **Spread** - Semakin kecil semakin baik
2. **Volatilitas** - Sesuaikan dengan risk tolerance
3. **Jam trading** - Trade saat pair aktif
4. **Korelasi** - Jangan double exposure
