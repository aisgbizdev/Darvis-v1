# Kesalahan Umum Trader Pemula

## Kategori 1: Risk Management Mistakes

### 1. Trading Tanpa Stop Loss
**Kesalahan:** Tidak memasang stop loss karena "nanti juga balik"

**Akibat:**
- Loss kecil menjadi loss besar
- Margin call
- Akun blow up

**Solusi:**
- SELALU pasang stop loss SEBELUM entry
- Tentukan risk per trade (max 1-2%)
- Accept bahwa loss adalah bagian dari trading

### 2. Overleveraging
**Kesalahan:** Menggunakan leverage maksimal untuk "maximize profit"

**Akibat:**
- Sedikit pergerakan melawan = loss besar
- Cepat margin call
- Tidak ada ruang untuk market bernapas

**Solusi:**
- Gunakan leverage bijak (max 1:20 untuk pemula)
- Fokus pada % return, bukan $ return
- Lebih baik grow account slowly than blow up fast

### 3. Tidak Menghitung Position Size
**Kesalahan:** Selalu pakai lot yang sama tanpa hitung risk

**Akibat:**
- Risk tidak konsisten per trade
- SL jauh = risk kebesaran
- SL dekat = bisa profitable tapi small gains

**Solusi:**
- Hitung position size berdasarkan jarak SL
- Gunakan formula: Lot = Risk $ / (SL pips × pip value)
- Konsisten 1-2% risk per trade

### 4. Revenge Trading
**Kesalahan:** Langsung entry setelah loss untuk "balas dendam"

**Akibat:**
- Trade tanpa setup yang jelas
- Emosional decision making
- Loss berlipat-lipat

**Solusi:**
- Set daily loss limit - stop trading jika tercapai
- Ambil break 15-30 menit setelah loss
- Besok adalah hari baru

## Kategori 2: Strategy Mistakes

### 5. Tidak Punya Trading Plan
**Kesalahan:** Trading "by feeling" atau intuisi tanpa plan

**Akibat:**
- Tidak konsisten
- Tidak bisa evaluate performa
- Emosi menguasai keputusan

**Solusi:**
- Tulis trading plan sebelum trading
- Definisikan: entry criteria, exit criteria, position size
- Backtest sebelum live trading

### 6. Ganti Strategy Terlalu Cepat
**Kesalahan:** Ganti strategy setelah beberapa loss

**Akibat:**
- Tidak pernah master satu strategy
- Tidak ada data cukup untuk evaluate
- Mencari "holy grail" yang tidak ada

**Solusi:**
- Berikan minimal 50-100 trades untuk evaluate strategy
- Losing streak adalah normal
- Fokus pada execution, bukan ganti strategy

### 7. Overtrading
**Kesalahan:** Trading terlalu sering, selalu ingin di market

**Akibat:**
- Banyak biaya spread/commission
- Forced trades tanpa setup bagus
- Fatigue dan emosional

**Solusi:**
- Quality over quantity
- Tidak ada trade lebih baik dari bad trade
- Set maximum trades per hari

### 8. Counter-Trend Trading
**Kesalahan:** Selalu mencoba menebak reversal, melawan trend

**Akibat:**
- "Catching falling knife"
- SL berulang kali terkena
- Miss profitable trend moves

**Solusi:**
- "Trend is your friend"
- Trade with the trend, bukan against it
- Tunggu konfirmasi reversal, bukan tebak

### 9. Tidak Memahami Timeframe
**Kesalahan:** Mixed signals karena tidak konsisten dengan timeframe

**Akibat:**
- Entry di M5, SL berdasarkan D1 = tidak matching
- Kebingungan dengan sinyal berbeda
- Inconsistent execution

**Solusi:**
- Pilih primary timeframe untuk trade
- Higher TF untuk trend direction
- Konsisten dengan timeframe analysis

## Kategori 3: Psychology Mistakes

### 10. FOMO (Fear of Missing Out)
**Kesalahan:** Entry terlambat karena lihat harga sudah naik

**Akibat:**
- Entry di harga buruk
- SL kena karena entry at top
- Profit kecil, loss besar

**Solusi:**
- Ada ribuan peluang lain
- If in doubt, stay out
- Lebih baik miss trade daripada bad trade

### 11. Moving Stop Loss
**Kesalahan:** Geser SL lebih jauh saat harga mendekati

**Akibat:**
- Small loss menjadi big loss
- Melanggar trading plan
- Bad habit yang sulit dihilangkan

**Solusi:**
- SL adalah asuransi - jangan digeser
- Set dan forget
- Accept small loss, it's cost of doing business

### 12. Taking Profit Terlalu Cepat
**Kesalahan:** Close profit kecil karena takut reversal

**Akibat:**
- Win besar jadi win kecil
- Risk/Reward tidak seimbang
- Butuh win rate sangat tinggi untuk profit

**Solusi:**
- Set take profit level dan patuhi
- Gunakan trailing stop
- "Cut losses short, let profits run"

### 13. Tidak Bisa Menerima Loss
**Kesalahan:** Menolak cut loss, berharap harga balik

**Akibat:**
- Small loss menjadi disaster
- Capital terkunci di bad trade
- Mental drain

**Solusi:**
- Loss adalah bagian dari trading
- Statistik: bahkan trader terbaik loss 40% trades
- Fokus pada overall performance, bukan per trade

## Kategori 4: Knowledge Mistakes

### 14. Trading Tanpa Edukasi
**Kesalahan:** Langsung live trading tanpa belajar dasar

**Akibat:**
- Tidak mengerti apa yang terjadi
- Keputusan berdasarkan keberuntungan
- Expensive lesson

**Solusi:**
- Pelajari dasar trading terlebih dahulu
- Praktik di demo account minimal 3 bulan
- Jangan skip education

### 15. Tidak Memahami Instrumen yang Ditrade
**Kesalahan:** Trade pair/instrumen tanpa tahu karakteristiknya

**Akibat:**
- Kaget dengan volatilitas tinggi (GBP/JPY)
- Tidak tau waktu aktif trading
- Miss important news events

**Solusi:**
- Pelajari karakteristik setiap instrumen
- Mulai dengan EUR/USD yang paling stable
- Tau faktor penggerak instrumen

### 16. Mengabaikan Fundamental
**Kesalahan:** Pure technical tanpa perhatikan news/data

**Akibat:**
- Kaget dengan pergerakan besar saat news
- SL terkena saat high impact event
- Miss big moves

**Solusi:**
- Selalu cek economic calendar
- Hindari trading saat high impact news (atau aware)
- Fundamental untuk direction, technical untuk timing

### 17. Terlalu Banyak Indikator
**Kesalahan:** Chart penuh indikator sampai harga tidak terlihat

**Akibat:**
- Analysis paralysis
- Sinyal bertentangan
- Tidak bisa ambil keputusan

**Solusi:**
- Maksimal 2-3 indikator
- Pilih yang saling melengkapi
- Price action tetap yang utama

## Kategori 5: Practical Mistakes

### 18. Trading dengan "Scared Money"
**Kesalahan:** Trading dengan uang yang tidak siap hilang

**Akibat:**
- Emosional setiap pergerakan
- Tidak bisa follow plan
- Stress level tinggi

**Solusi:**
- Hanya trade dengan "risk capital"
- Jangan trade uang kebutuhan hidup
- If you can't afford to lose it, don't trade it

### 19. Tidak Mencatat (Journaling)
**Kesalahan:** Tidak punya trading journal

**Akibat:**
- Tidak bisa evaluate performa
- Repeat same mistakes
- Tidak tahu apa yang works

**Solusi:**
- Catat SETIAP trade
- Review mingguan/bulanan
- Identifikasi pola kesalahan

### 20. Mengikuti Signal Orang Lain Tanpa Mengerti
**Kesalahan:** Blind follow signal provider atau "guru trading"

**Akibat:**
- Tidak belajar analisis sendiri
- Tidak tau kapan entry/exit jika provider tidak update
- Scam risk tinggi

**Solusi:**
- Pelajari cara analisis sendiri
- Jika follow signal, pahami alasannya
- Waspada terhadap "profit pasti" - tidak ada yang pasti

## Checklist Menghindari Kesalahan

Sebelum setiap trade, tanyakan:

1. [ ] Apakah ada setup yang jelas sesuai trading plan?
2. [ ] Apakah SL sudah ditentukan SEBELUM entry?
3. [ ] Apakah position size sudah dihitung (max 1-2% risk)?
4. [ ] Apakah ada high impact news dalam waktu dekat?
5. [ ] Apakah saya dalam kondisi emosi netral?
6. [ ] Apakah ini trade, bukan gambling?
7. [ ] Apakah saya ready jika trade ini loss?

Jika ada yang tidak terpenuhi, JANGAN TRADE!
